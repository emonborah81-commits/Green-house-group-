create extension if not exists pgcrypto;
create table if not exists public.events (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 category text not null check(category in ('Sports','Cultural')),
 is_open boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.participants (
 id uuid primary key default gen_random_uuid(),
 student_name text not null,
 class_section text not null,
 event_id uuid not null references public.events(id) on delete restrict,
 created_at timestamptz not null default now()
);
alter table public.events enable row level security;
alter table public.participants enable row level security;
-- Starter policies: public can view open events and submit registrations.
-- Restrict/review this setup before using with actual school student data.
create policy "view open events" on public.events for select using (is_open=true);
create policy "submit registration" on public.participants for insert with check (true);
insert into public.events(name,category) values
 ('100m Race','Sports'),('200m Race','Sports'),('400m Race','Sports'),('Relay','Sports'),('Long Jump','Sports'),('High Jump','Sports'),('Shot Put','Sports'),('Football','Sports'),('Volleyball','Sports'),('Cricket','Sports'),('Badminton','Sports'),('Chess','Sports'),('Quiz','Cultural'),('Dance','Cultural'),('Music','Cultural'),('Drama','Cultural'),('Drawing','Cultural')
on conflict do nothing;
