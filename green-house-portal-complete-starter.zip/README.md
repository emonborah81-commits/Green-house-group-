# Green House — Sports & Cultural Participation Portal

Mobile-first starter app for Green House at Rev. William Ward Senior Secondary School.

## Run locally
1. Install Node.js 20+ and npm.
2. In this project folder, run `npm install`.
3. Copy `.env.example` to `.env.local` and fill in the Supabase URL and anon key.
4. Run `npm run dev`, then open http://localhost:3000.

## Supabase
Create a Supabase project and run `supabase/schema.sql` in the SQL Editor. This starter provides a basic event list and registration flow. Before collecting real student information, have a school adult review privacy, authorization, retention and security. Do not publish sensitive student data.

## Included
Home page, student registration form, management login route placeholder, dashboard placeholder, SQL schema and event seeds.
