import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "Green House | Sports & Cultural Portal", description: "Green House participation portal" };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }